#!/usr/bin/env bash
set -euo pipefail

# ─────────────────────────────────────────────────────────────────────────────
# Cores e utilitários
# ─────────────────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; MAGENTA='\033[0;35m'
BOLD='\033[1m'; DIM='\033[2m'; NC='\033[0m'

NAMESPACE="observability"
STACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SECRET_FILE="${STACK_DIR}/grafana/secret.yaml"

info()    { echo -e "  ${CYAN}ℹ${NC}  $*"; }
ok()      { echo -e "  ${GREEN}✔${NC}  $*"; }
warn()    { echo -e "  ${YELLOW}⚠${NC}  $*"; }
err()     { echo -e "  ${RED}✖${NC}  $*"; }
step()    { echo -e "\n${BOLD}${BLUE}▶  $*${NC}"; }
divider() { echo -e "${DIM}──────────────────────────────────────────────────────${NC}"; }
pause()   { echo; echo -ne "  ${DIM}Pressione Enter para continuar...${NC}"; read -r; }

# ─────────────────────────────────────────────────────────────────────────────
# Cabeçalho
# ─────────────────────────────────────────────────────────────────────────────
header() {
  clear
  echo -e "${BOLD}${BLUE}"
  echo "  ╔══════════════════════════════════════════════════════════╗"
  echo "  ║        Plataforma de Observabilidade Kubernetes          ║"
  echo "  ║        Menu de Deploy                                    ║"
  echo "  ╚══════════════════════════════════════════════════════════╝"
  echo -e "${NC}"

  local ctx
  ctx=$(kubectl config current-context 2>/dev/null || echo "desconectado")
  local server
  server=$(kubectl cluster-info 2>/dev/null | grep "control plane" | awk '{print $NF}' || echo "—")

  echo -e "  ${DIM}Cluster:${NC}    ${CYAN}${ctx}${NC}"
  echo -e "  ${DIM}Servidor:${NC}   ${CYAN}${server}${NC}"

  if kubectl get namespace "$NAMESPACE" &>/dev/null; then
    local running total
    running=$(kubectl get pods -n "$NAMESPACE" --no-headers 2>/dev/null | grep -c "Running" || echo 0)
    total=$(kubectl get pods   -n "$NAMESPACE" --no-headers 2>/dev/null | wc -l | tr -d ' ')
    echo -e "  ${DIM}Namespace:${NC}  ${CYAN}${NAMESPACE}${NC}  ${DIM}│${NC}  Pods: ${GREEN}${running} Running${NC} / ${total} total"
  else
    echo -e "  ${DIM}Namespace:${NC}  ${YELLOW}${NAMESPACE} (ainda não existe)${NC}"
  fi
  echo
  divider
}

# ─────────────────────────────────────────────────────────────────────────────
# Menu principal
# ─────────────────────────────────────────────────────────────────────────────
menu() {
  echo
  echo -e "  ${BOLD}Deploy${NC}"
  echo -e "  ${GREEN}1${NC}  Novo deploy completo"
  echo -e "  ${GREEN}2${NC}  Atualizar stack (apply)"
  echo -e "  ${GREEN}3${NC}  Rollback de um componente"
  echo
  echo -e "  ${BOLD}Validação${NC}"
  echo -e "  ${CYAN}4${NC}  Pré-flight check (pré-requisitos + manifests)"
  echo -e "  ${CYAN}5${NC}  Ver diff (estado atual vs manifests)"
  echo -e "  ${CYAN}6${NC}  Verificar saúde após deploy"
  echo
  echo -e "  ${BOLD}Configuração${NC}"
  echo -e "  ${MAGENTA}7${NC}  Configurar senha do Grafana"
  echo -e "  ${MAGENTA}8${NC}  Configurar integrações do Alertmanager"
  echo
  echo -e "  ${BOLD}Remoção${NC}"
  echo -e "  ${RED}9${NC}  Remover stack (preserva PVCs)"
  echo -e "  ${RED}10${NC} Remover stack e PVCs (DESTRUTIVO)"
  echo
  echo -e "  ${DIM}0  Sair${NC}"
  echo
  divider
  echo -ne "  ${BOLD}Escolha:${NC} "
}

# ─────────────────────────────────────────────────────────────────────────────
# 1 — Novo deploy completo
# ─────────────────────────────────────────────────────────────────────────────
action_deploy() {
  step "Novo deploy completo"

  # Verifica senha padrão
  if grep -q 'Observability@2024!' "$SECRET_FILE" 2>/dev/null; then
    warn "A senha padrão do Grafana ainda está em uso."
    echo -ne "  Deseja configurá-la agora? ${BOLD}[s/N]${NC} "
    read -r resp
    [[ "$resp" == [sS] ]] && action_grafana_secret
  fi

  # Dry-run
  step "Validando manifests (dry-run)"
  if kubectl apply -k "$STACK_DIR" --dry-run=client -o name 2>&1 | head -20; then
    ok "Manifests válidos."
  else
    err "Validação falhou. Corrija os erros antes de continuar."
    pause; return
  fi

  echo
  warn "Esta ação irá criar todos os recursos no namespace '${NAMESPACE}'."
  echo -ne "  Confirma o deploy? ${BOLD}[s/N]${NC} "
  read -r confirm
  [[ "$confirm" != [sS] ]] && { info "Deploy cancelado."; pause; return; }

  step "Aplicando manifests"
  cd "$STACK_DIR"
  kubectl apply -k .

  step "Aguardando pods ficarem prontos (timeout: 5 min)"
  _wait_rollout

  echo
  ok "Deploy concluído!"
  action_health
  pause
}

# ─────────────────────────────────────────────────────────────────────────────
# 2 — Atualizar stack
# ─────────────────────────────────────────────────────────────────────────────
action_update() {
  step "Atualizar stack"
  cd "$STACK_DIR"

  step "Diff entre manifests e cluster"
  kubectl diff -k . 2>/dev/null || true

  echo
  echo -ne "  Aplicar as alterações acima? ${BOLD}[s/N]${NC} "
  read -r confirm
  [[ "$confirm" != [sS] ]] && { info "Operação cancelada."; pause; return; }

  kubectl apply -k .
  ok "Alterações aplicadas."
  _wait_rollout
  pause
}

# ─────────────────────────────────────────────────────────────────────────────
# 3 — Rollback de componente
# ─────────────────────────────────────────────────────────────────────────────
action_rollback() {
  step "Rollback de componente"

  echo -e "  ${CYAN}1${NC} prometheus          ${CYAN}4${NC} alertmanager"
  echo -e "  ${CYAN}2${NC} grafana             ${CYAN}5${NC} kube-state-metrics"
  echo -e "  ${CYAN}3${NC} loki (statefulset)"
  echo
  echo -ne "  Componente: "
  read -r choice

  case "$choice" in
    1) comp="prometheus";         kind="deployment" ;;
    2) comp="grafana";            kind="deployment" ;;
    3) comp="loki";               kind="statefulset" ;;
    4) comp="alertmanager";       kind="deployment" ;;
    5) comp="kube-state-metrics"; kind="deployment" ;;
    *) warn "Opção inválida."; pause; return ;;
  esac

  # Histórico de revisões
  echo
  info "Histórico de revisões de ${comp}:"
  kubectl rollout history "${kind}/${comp}" -n "$NAMESPACE" 2>/dev/null || { err "Componente não encontrado no cluster."; pause; return; }

  echo
  echo -ne "  Número da revisão para rollback (vazio = revisão anterior): "
  read -r rev

  if [[ -n "$rev" ]]; then
    kubectl rollout undo "${kind}/${comp}" -n "$NAMESPACE" --to-revision="$rev"
  else
    kubectl rollout undo "${kind}/${comp}" -n "$NAMESPACE"
  fi

  kubectl rollout status "${kind}/${comp}" -n "$NAMESPACE" --timeout=120s
  ok "Rollback de ${comp} concluído."
  pause
}

# ─────────────────────────────────────────────────────────────────────────────
# 4 — Pré-flight check
# ─────────────────────────────────────────────────────────────────────────────
action_preflight() {
  step "Pré-flight check"
  local failed=0

  # kubectl
  if command -v kubectl &>/dev/null; then
    ok "kubectl:   $(kubectl version --client -o json 2>/dev/null | grep '"gitVersion"' | head -1 | awk -F'"' '{print $4}')"
  else
    err "kubectl não encontrado."; failed=1
  fi

  # Kustomize (embutido)
  if kubectl kustomize --help &>/dev/null 2>&1; then
    ok "kustomize: embutido no kubectl"
  else
    err "kustomize não disponível."; failed=1
  fi

  # Conexão com cluster
  if kubectl cluster-info &>/dev/null 2>&1; then
    ok "Cluster:   $(kubectl config current-context)"
  else
    err "Sem conexão com o cluster Kubernetes."; failed=1
  fi

  # Versão do servidor
  local server_ver
  server_ver=$(kubectl version -o json 2>/dev/null | grep -A1 '"serverVersion"' | grep '"gitVersion"' | awk -F'"' '{print $4}' || echo "—")
  info "Versão do servidor: ${server_ver}"

  # Validação dry-run
  echo
  info "Validando manifests (dry-run)..."
  if kubectl apply -k "$STACK_DIR" --dry-run=client -o name 2>&1 | tail -3; then
    ok "Todos os manifests são válidos."
  else
    err "Falha na validação dos manifests."; failed=1
  fi

  # Senha padrão
  if grep -q 'Observability@2024!' "$SECRET_FILE" 2>/dev/null; then
    warn "Senha padrão do Grafana detectada em ${SECRET_FILE}. Troque antes de ir para produção."
  else
    ok "Senha do Grafana: customizada."
  fi

  echo
  [[ "$failed" -eq 0 ]] && ok "Pré-flight check aprovado. Pronto para deploy." \
                         || err "Corrija os itens acima antes de continuar."
  pause
}

# ─────────────────────────────────────────────────────────────────────────────
# 5 — Diff
# ─────────────────────────────────────────────────────────────────────────────
action_diff() {
  step "Diff: manifests vs cluster"
  cd "$STACK_DIR"
  kubectl diff -k . 2>/dev/null && ok "Cluster está sincronizado com os manifests." || true
  pause
}

# ─────────────────────────────────────────────────────────────────────────────
# 6 — Verificar saúde
# ─────────────────────────────────────────────────────────────────────────────
action_health() {
  step "Verificação de saúde — namespace: ${NAMESPACE}"
  local failed=0

  echo
  echo -e "  ${BOLD}Pods:${NC}"
  kubectl get pods -n "$NAMESPACE" -o wide 2>/dev/null \
    | awk 'NR==1 { print "  " $0 }
           NR>1 && /Running/  { print "\033[0;32m  " $0 "\033[0m" }
           NR>1 && !/Running/ { print "\033[0;31m  " $0 "\033[0m" }'

  echo
  echo -e "  ${BOLD}Deployments:${NC}"
  kubectl get deployments -n "$NAMESPACE" 2>/dev/null \
    | awk 'NR==1 { print "  " $0 }
           NR>1  { print "  " $0 }'

  echo
  echo -e "  ${BOLD}StatefulSets:${NC}"
  kubectl get statefulsets -n "$NAMESPACE" 2>/dev/null \
    | awk 'NR==1 { print "  " $0 }
           NR>1  { print "  " $0 }'

  echo
  echo -e "  ${BOLD}PersistentVolumeClaims:${NC}"
  kubectl get pvc -n "$NAMESPACE" 2>/dev/null \
    | awk 'NR==1 { print "  " $0 }
           NR>1 && /Bound/   { print "\033[0;32m  " $0 "\033[0m" }
           NR>1 && !/Bound/  { print "\033[0;31m  " $0 "\033[0m" }'

  # Pods não Running
  local not_running
  not_running=$(kubectl get pods -n "$NAMESPACE" --no-headers 2>/dev/null | grep -v "Running" | grep -v "Completed" || true)
  if [[ -n "$not_running" ]]; then
    echo
    warn "Pods fora do estado Running:"
    echo "$not_running" | awk '{ print "  " $0 }'
    failed=1
  fi

  echo
  [[ "$failed" -eq 0 ]] && ok "Todos os componentes estão saudáveis." \
                         || warn "Verifique os pods acima. Use 'make logs COMP=<nome>' para diagnosticar."
}

# ─────────────────────────────────────────────────────────────────────────────
# 7 — Configurar senha do Grafana
# ─────────────────────────────────────────────────────────────────────────────
action_grafana_secret() {
  step "Configurar senha do Grafana"
  info "Arquivo: ${SECRET_FILE}"
  echo

  local current
  current=$(grep 'admin-password:' "$SECRET_FILE" | awk -F'"' '{print $2}')
  info "Senha atual: ${current}"
  echo

  echo -ne "  Nova senha (mín. 8 caracteres): "
  read -rs new_pass
  echo

  if [[ ${#new_pass} -lt 8 ]]; then
    err "Senha muito curta. Operação cancelada."
    pause; return
  fi

  echo -ne "  Confirme a nova senha: "
  read -rs confirm_pass
  echo

  if [[ "$new_pass" != "$confirm_pass" ]]; then
    err "As senhas não coincidem. Operação cancelada."
    pause; return
  fi

  # Atualiza o arquivo
  sed -i "s|admin-password:.*|admin-password: \"${new_pass}\"|" "$SECRET_FILE"
  ok "Senha atualizada em ${SECRET_FILE}."

  # Atualiza no cluster se já existe
  if kubectl get secret grafana-credentials -n "$NAMESPACE" &>/dev/null; then
    echo
    echo -ne "  Aplicar a nova senha no cluster agora? ${BOLD}[s/N]${NC} "
    read -r apply
    if [[ "$apply" == [sS] ]]; then
      kubectl apply -f "$SECRET_FILE"
      kubectl rollout restart deployment/grafana -n "$NAMESPACE"
      kubectl rollout status  deployment/grafana -n "$NAMESPACE" --timeout=120s
      ok "Grafana reiniciado com a nova senha."
    else
      info "Execute 'make apply' para sincronizar com o cluster."
    fi
  fi
  pause
}

# ─────────────────────────────────────────────────────────────────────────────
# 8 — Configurar Alertmanager
# ─────────────────────────────────────────────────────────────────────────────
action_alertmanager_config() {
  local cfg="${STACK_DIR}/alertmanager/configmap.yaml"
  step "Configurar integrações do Alertmanager"
  info "Arquivo: ${cfg}"
  echo

  echo -e "  ${BOLD}Integrações disponíveis:${NC}"
  echo -e "  ${CYAN}1${NC}  Microsoft Teams"
  echo -e "  ${CYAN}2${NC}  Slack"
  echo -e "  ${CYAN}3${NC}  E-mail (SMTP)"
  echo -e "  ${CYAN}4${NC}  Abrir arquivo no editor (\$EDITOR)"
  echo -e "  ${CYAN}0${NC}  Voltar"
  echo
  echo -ne "  Escolha: "
  read -r choice

  case "$choice" in
    1)
      echo -ne "  URL do webhook Teams: "
      read -r url
      sed -i "s|https://your-org.webhook.office.com/webhookb2/CHANGEME|${url}|g" "$cfg"
      ok "Teams configurado."
      ;;
    2)
      echo -ne "  URL do webhook Slack (critical): "
      read -r url_crit
      echo -ne "  URL do webhook Slack (warning):  "
      read -r url_warn
      # Substitui as duas ocorrências de CHANGEME em ordem
      local count=0
      while IFS= read -r line; do
        if echo "$line" | grep -q "hooks.slack.com.*CHANGEME" && [[ $count -eq 0 ]]; then
          echo "${line/CHANGEME/${url_crit##*/}}" | sed "s|https://hooks.slack.com/services/CHANGEME|${url_crit}|"
          count=1
        elif echo "$line" | grep -q "hooks.slack.com.*CHANGEME" && [[ $count -eq 1 ]]; then
          echo "${line}" | sed "s|https://hooks.slack.com/services/CHANGEME|${url_warn}|"
          count=2
        else
          echo "$line"
        fi
      done < "$cfg" > "${cfg}.tmp" && mv "${cfg}.tmp" "$cfg"
      ok "Slack configurado."
      ;;
    3)
      echo -ne "  SMTP host:port (ex: smtp.example.com:587): "
      read -r smtp
      echo -ne "  Endereço de destino (to): "
      read -r to_addr
      sed -i "s|smtp.example.com:587|${smtp}|g" "$cfg"
      sed -i "s|ops-team@example.com|${to_addr}|g" "$cfg"
      ok "E-mail configurado."
      ;;
    4)
      ${EDITOR:-vi} "$cfg"
      ok "Arquivo salvo."
      ;;
    0) return ;;
    *) warn "Opção inválida." ;;
  esac

  echo
  echo -ne "  Aplicar a configuração no cluster agora? ${BOLD}[s/N]${NC} "
  read -r apply
  if [[ "$apply" == [sS] ]]; then
    kubectl apply -f "$cfg"
    kubectl rollout restart deployment/alertmanager -n "$NAMESPACE"
    ok "Alertmanager reiniciado com a nova configuração."
  else
    info "Execute 'make apply' para sincronizar com o cluster."
  fi
  pause
}

# ─────────────────────────────────────────────────────────────────────────────
# 9 — Remover stack (preserva PVCs)
# ─────────────────────────────────────────────────────────────────────────────
action_remove() {
  step "Remover stack de observabilidade"
  echo
  warn "Esta ação remove todos os recursos do namespace '${NAMESPACE}'."
  warn "Os dados persistentes (PVCs) serão preservados."
  echo
  echo -ne "  ${BOLD}${RED}Digite 'remover' para confirmar:${NC} "
  read -r confirm
  [[ "$confirm" != "remover" ]] && { info "Operação cancelada."; pause; return; }

  cd "$STACK_DIR"
  kubectl delete -k . --ignore-not-found=true
  ok "Stack removida. PVCs preservados."
  pause
}

# ─────────────────────────────────────────────────────────────────────────────
# 10 — Remover tudo (inclui PVCs)
# ─────────────────────────────────────────────────────────────────────────────
action_remove_all() {
  step "Remover stack + PVCs (DESTRUTIVO)"
  echo
  err "ATENÇÃO: Esta operação é IRREVERSÍVEL. Todos os dados serão perdidos."
  echo
  echo -ne "  ${BOLD}${RED}Digite 'CONFIRMO REMOVER TUDO' para prosseguir:${NC} "
  read -r confirm
  [[ "$confirm" != "CONFIRMO REMOVER TUDO" ]] && { info "Operação cancelada."; pause; return; }

  cd "$STACK_DIR"
  kubectl delete -k . --ignore-not-found=true
  kubectl delete pvc --all -n "$NAMESPACE" --ignore-not-found=true
  ok "Stack e dados removidos."
  pause
}

# ─────────────────────────────────────────────────────────────────────────────
# Helper — aguarda rollout de todos os componentes
# ─────────────────────────────────────────────────────────────────────────────
_wait_rollout() {
  local deployments=("prometheus" "grafana" "alertmanager" "kube-state-metrics")
  local statefulsets=("loki")

  for d in "${deployments[@]}"; do
    info "Aguardando deployment/${d}..."
    kubectl rollout status "deployment/${d}" -n "$NAMESPACE" --timeout=300s 2>/dev/null \
      && ok "${d} pronto." \
      || warn "${d}: verifique com 'make logs COMP=${d}'"
  done

  for s in "${statefulsets[@]}"; do
    info "Aguardando statefulset/${s}..."
    kubectl rollout status "statefulset/${s}" -n "$NAMESPACE" --timeout=300s 2>/dev/null \
      && ok "${s} pronto." \
      || warn "${s}: verifique com 'make logs COMP=${s}'"
  done
}

# ─────────────────────────────────────────────────────────────────────────────
# Loop principal
# ─────────────────────────────────────────────────────────────────────────────
main() {
  while true; do
    header
    menu
    read -r opt

    case "$opt" in
      1)  action_deploy ;;
      2)  action_update ;;
      3)  action_rollback ;;
      4)  action_preflight ;;
      5)  action_diff ;;
      6)  action_health; pause ;;
      7)  action_grafana_secret ;;
      8)  action_alertmanager_config ;;
      9)  action_remove ;;
      10) action_remove_all ;;
      0)  echo -e "\n  ${DIM}Até logo.${NC}\n"; exit 0 ;;
      *)  warn "Opção inválida."; sleep 1 ;;
    esac
  done
}

main "$@"
