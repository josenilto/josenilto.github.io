#!/usr/bin/env bash
set -euo pipefail

# ─────────────────────────────────────────────
# Cores
# ─────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
BOLD='\033[1m'
DIM='\033[2m'
NC='\033[0m'

NAMESPACE="observability"
STACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ─────────────────────────────────────────────
# Utilitários de output
# ─────────────────────────────────────────────
info()    { echo -e "${CYAN}[INFO]${NC}  $*"; }
success() { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error()   { echo -e "${RED}[ERRO]${NC}  $*"; }
step()    { echo -e "\n${BOLD}${BLUE}▶ $*${NC}"; }
divider() { echo -e "${DIM}──────────────────────────────────────────────────${NC}"; }

# ─────────────────────────────────────────────
# Verifica pré-requisitos
# ─────────────────────────────────────────────
check_prerequisites() {
  local missing=0

  step "Verificando pré-requisitos"

  if command -v kubectl &>/dev/null; then
    success "kubectl:   $(kubectl version --client --short 2>/dev/null | head -1)"
  else
    error "kubectl não encontrado. Instale antes de continuar."
    missing=1
  fi

  if command -v kustomize &>/dev/null; then
    success "kustomize: $(kustomize version --short 2>/dev/null)"
  elif kubectl kustomize --help &>/dev/null; then
    success "kustomize: embutido no kubectl"
  else
    error "kustomize não encontrado."
    missing=1
  fi

  if kubectl cluster-info &>/dev/null; then
    success "Cluster:   $(kubectl config current-context)"
  else
    error "Sem conexão com o cluster Kubernetes."
    missing=1
  fi

  [ "$missing" -eq 1 ] && { echo; error "Corrija os pré-requisitos acima e tente novamente."; exit 1; }
  echo
}

# ─────────────────────────────────────────────
# Cabeçalho do painel
# ─────────────────────────────────────────────
header() {
  clear
  echo -e "${BOLD}${BLUE}"
  echo "╔══════════════════════════════════════════════════════════╗"
  echo "║       Plataforma de Observabilidade Kubernetes           ║"
  echo "║       Prometheus · Loki · Grafana · Alertmanager         ║"
  echo "╚══════════════════════════════════════════════════════════╝"
  echo -e "${NC}"

  # Exibe contexto e status do namespace
  local ctx
  ctx=$(kubectl config current-context 2>/dev/null || echo "desconectado")
  echo -e "  ${DIM}Cluster:${NC}    ${CYAN}${ctx}${NC}"

  if kubectl get namespace "$NAMESPACE" &>/dev/null; then
    local running
    running=$(kubectl get pods -n "$NAMESPACE" --no-headers 2>/dev/null | grep -c "Running" || echo 0)
    local total
    total=$(kubectl get pods -n "$NAMESPACE" --no-headers 2>/dev/null | wc -l | tr -d ' ')
    echo -e "  ${DIM}Namespace:${NC}  ${CYAN}${NAMESPACE}${NC}  ${DIM}│${NC}  Pods: ${GREEN}${running} running${NC} / ${total} total"
  else
    echo -e "  ${DIM}Namespace:${NC}  ${YELLOW}${NAMESPACE} (não existe ainda)${NC}"
  fi

  echo
  divider
}

# ─────────────────────────────────────────────
# Menu principal
# ─────────────────────────────────────────────
menu() {
  echo
  echo -e "  ${BOLD}Operações${NC}"
  echo -e "  ${GREEN}1${NC}  Provisionar stack completa"
  echo -e "  ${GREEN}2${NC}  Aplicar alterações"
  echo -e "  ${GREEN}3${NC}  Remover stack"
  echo
  echo -e "  ${BOLD}Monitoramento${NC}"
  echo -e "  ${CYAN}4${NC}  Status dos componentes"
  echo -e "  ${CYAN}5${NC}  Ver logs de um componente"
  echo -e "  ${CYAN}6${NC}  Descrever um pod"
  echo
  echo -e "  ${BOLD}Acesso${NC}"
  echo -e "  ${MAGENTA}7${NC}  Abrir Grafana        (port-forward :3000)"
  echo -e "  ${MAGENTA}8${NC}  Abrir Prometheus     (port-forward :9090)"
  echo -e "  ${MAGENTA}9${NC}  Abrir Alertmanager   (port-forward :9093)"
  echo
  echo -e "  ${BOLD}Manutenção${NC}"
  echo -e "  ${YELLOW}10${NC} Reiniciar um componente"
  echo -e "  ${YELLOW}11${NC} Editar Secret do Grafana"
  echo -e "  ${YELLOW}12${NC} Verificar Network Policies"
  echo
  echo -e "  ${RED}0${NC}  Sair"
  echo
  divider
  echo -ne "  ${BOLD}Escolha uma opção:${NC} "
}

# ─────────────────────────────────────────────
# Ação 1 — Provisionar
# ─────────────────────────────────────────────
action_provision() {
  step "Provisionando stack de observabilidade"
  warn "Esta ação irá criar todos os recursos no namespace '${NAMESPACE}'."
  echo -ne "  Confirma? ${BOLD}[s/N]${NC} "
  read -r confirm
  [[ "$confirm" != [sS] ]] && { info "Operação cancelada."; return; }

  cd "$STACK_DIR"
  info "Aplicando manifests via kustomize..."
  kubectl apply -k .

  echo
  step "Aguardando pods ficarem prontos (timeout: 3 minutos)..."
  local components=("prometheus" "grafana" "loki" "alertmanager" "kube-state-metrics")
  for comp in "${components[@]}"; do
    info "Aguardando: ${comp}"
    kubectl rollout status deployment/"$comp" -n "$NAMESPACE" --timeout=180s 2>/dev/null \
      || kubectl rollout status statefulset/"$comp" -n "$NAMESPACE" --timeout=180s 2>/dev/null \
      || warn "${comp}: verifique manualmente com a opção 4"
  done

  echo
  success "Stack provisionada com sucesso!"
  kubectl get pods -n "$NAMESPACE"
  pause
}

# ─────────────────────────────────────────────
# Ação 2 — Aplicar alterações
# ─────────────────────────────────────────────
action_apply() {
  step "Aplicando alterações"
  cd "$STACK_DIR"

  info "Exibindo diff antes de aplicar..."
  kubectl diff -k . 2>/dev/null || true

  echo
  echo -ne "  Confirma aplicação? ${BOLD}[s/N]${NC} "
  read -r confirm
  [[ "$confirm" != [sS] ]] && { info "Operação cancelada."; return; }

  kubectl apply -k .
  success "Alterações aplicadas."
  pause
}

# ─────────────────────────────────────────────
# Ação 3 — Remover stack
# ─────────────────────────────────────────────
action_remove() {
  step "Remover stack de observabilidade"
  echo
  warn "ATENÇÃO: Esta ação irá remover TODOS os recursos do namespace '${NAMESPACE}'."
  warn "Os dados persistentes (PVCs) serão preservados a menos que removidos manualmente."
  echo
  echo -ne "  ${RED}${BOLD}Digite 'remover' para confirmar:${NC} "
  read -r confirm
  [[ "$confirm" != "remover" ]] && { info "Operação cancelada."; return; }

  cd "$STACK_DIR"
  kubectl delete -k . --ignore-not-found=true

  echo
  echo -ne "  Remover também os PVCs (dados persistentes)? ${BOLD}[s/N]${NC} "
  read -r remove_pvcs
  if [[ "$remove_pvcs" == [sS] ]]; then
    kubectl delete pvc --all -n "$NAMESPACE" --ignore-not-found=true
    success "PVCs removidos."
  else
    info "PVCs preservados."
  fi

  success "Stack removida."
  pause
}

# ─────────────────────────────────────────────
# Ação 4 — Status
# ─────────────────────────────────────────────
action_status() {
  step "Status dos componentes — namespace: ${NAMESPACE}"

  echo -e "\n${BOLD}Pods:${NC}"
  kubectl get pods -n "$NAMESPACE" -o wide 2>/dev/null \
    | awk 'NR==1{print} NR>1 && /Running/{print "\033[0;32m" $0 "\033[0m"} NR>1 && !/Running/{print "\033[0;31m" $0 "\033[0m"}'

  echo -e "\n${BOLD}Services:${NC}"
  kubectl get services -n "$NAMESPACE" 2>/dev/null

  echo -e "\n${BOLD}PersistentVolumeClaims:${NC}"
  kubectl get pvc -n "$NAMESPACE" 2>/dev/null

  echo -e "\n${BOLD}Eventos recentes (últimos 10):${NC}"
  kubectl get events -n "$NAMESPACE" --sort-by='.lastTimestamp' 2>/dev/null | tail -10

  pause
}

# ─────────────────────────────────────────────
# Ação 5 — Logs
# ─────────────────────────────────────────────
action_logs() {
  step "Ver logs de componente"

  echo -e "  Componentes disponíveis:"
  echo -e "  ${CYAN}1${NC} prometheus      ${CYAN}5${NC} alertmanager"
  echo -e "  ${CYAN}2${NC} grafana         ${CYAN}6${NC} node-exporter"
  echo -e "  ${CYAN}3${NC} loki            ${CYAN}7${NC} kube-state-metrics"
  echo -e "  ${CYAN}4${NC} promtail        ${CYAN}8${NC} Digitar nome manualmente"
  echo
  echo -ne "  Escolha: "
  read -r choice

  case "$choice" in
    1) comp="prometheus" ;;
    2) comp="grafana" ;;
    3) comp="loki" ;;
    4) comp="promtail" ;;
    5) comp="alertmanager" ;;
    6) comp="node-exporter" ;;
    7) comp="kube-state-metrics" ;;
    8) echo -ne "  Nome do pod/deployment: "; read -r comp ;;
    *) warn "Opção inválida."; return ;;
  esac

  echo -ne "  Número de linhas [100]: "
  read -r lines
  lines="${lines:-100}"

  echo -ne "  Seguir logs em tempo real? [s/N]: "
  read -r follow

  local follow_flag=""
  [[ "$follow" == [sS] ]] && follow_flag="-f"

  echo
  info "Exibindo logs de '${comp}' (Ctrl+C para sair)..."
  kubectl logs -n "$NAMESPACE" -l "app.kubernetes.io/name=${comp}" \
    --tail="$lines" $follow_flag --all-containers=true 2>/dev/null \
    || kubectl logs -n "$NAMESPACE" "$comp" --tail="$lines" $follow_flag 2>/dev/null \
    || error "Pod '${comp}' não encontrado."

  pause
}

# ─────────────────────────────────────────────
# Ação 6 — Descrever pod
# ─────────────────────────────────────────────
action_describe() {
  step "Descrever pod"

  echo -e "  Pods no namespace ${NAMESPACE}:\n"
  kubectl get pods -n "$NAMESPACE" --no-headers 2>/dev/null | awk '{print "  " NR". "$1}'
  echo
  echo -ne "  Nome do pod: "
  read -r pod_name

  kubectl describe pod "$pod_name" -n "$NAMESPACE" 2>/dev/null \
    || error "Pod '${pod_name}' não encontrado."

  pause
}

# ─────────────────────────────────────────────
# Port-forwards
# ─────────────────────────────────────────────
port_forward() {
  local svc=$1
  local port=$2
  local label=$3

  step "Abrindo ${label} via port-forward"
  info "Acesse em: http://localhost:${port}"
  info "Pressione Ctrl+C para encerrar."
  echo
  kubectl port-forward -n "$NAMESPACE" "svc/${svc}" "${port}:${port}"
}

# ─────────────────────────────────────────────
# Ação 10 — Reiniciar componente
# ─────────────────────────────────────────────
action_restart() {
  step "Reiniciar componente"

  echo -e "  ${CYAN}1${NC} prometheus        ${CYAN}4${NC} alertmanager"
  echo -e "  ${CYAN}2${NC} grafana           ${CYAN}5${NC} kube-state-metrics"
  echo -e "  ${CYAN}3${NC} loki"
  echo
  echo -ne "  Escolha: "
  read -r choice

  case "$choice" in
    1) comp="prometheus"; kind="deployment" ;;
    2) comp="grafana";    kind="deployment" ;;
    3) comp="loki";       kind="statefulset" ;;
    4) comp="alertmanager"; kind="deployment" ;;
    5) comp="kube-state-metrics"; kind="deployment" ;;
    *) warn "Opção inválida."; return ;;
  esac

  kubectl rollout restart "${kind}/${comp}" -n "$NAMESPACE"
  success "${comp} reiniciado."
  kubectl rollout status "${kind}/${comp}" -n "$NAMESPACE" --timeout=120s
  pause
}

# ─────────────────────────────────────────────
# Ação 11 — Editar Secret do Grafana
# ─────────────────────────────────────────────
action_edit_secret() {
  step "Editar credenciais do Grafana"
  warn "Recomendado: edite grafana/secret.yaml e use 'Aplicar alterações' (opção 2)."
  echo
  echo -ne "  Editar o Secret diretamente no cluster? [s/N]: "
  read -r confirm
  [[ "$confirm" != [sS] ]] && { info "Edite o arquivo grafana/secret.yaml manualmente."; pause; return; }

  kubectl edit secret grafana-credentials -n "$NAMESPACE"
  info "Reiniciando Grafana para aplicar as novas credenciais..."
  kubectl rollout restart deployment/grafana -n "$NAMESPACE"
  success "Grafana reiniciado com novas credenciais."
  pause
}

# ─────────────────────────────────────────────
# Ação 12 — Network Policies
# ─────────────────────────────────────────────
action_netpol() {
  step "Network Policies — namespace: ${NAMESPACE}"

  kubectl get networkpolicies -n "$NAMESPACE" -o wide 2>/dev/null

  echo
  echo -ne "  Detalhar uma política? [s/N]: "
  read -r confirm
  if [[ "$confirm" == [sS] ]]; then
    echo -ne "  Nome da política: "
    read -r pol
    kubectl describe networkpolicy "$pol" -n "$NAMESPACE" 2>/dev/null \
      || error "NetworkPolicy '${pol}' não encontrada."
  fi

  pause
}

# ─────────────────────────────────────────────
# Utilitário pause
# ─────────────────────────────────────────────
pause() {
  echo
  echo -ne "  ${DIM}Pressione Enter para voltar ao menu...${NC}"
  read -r
}

# ─────────────────────────────────────────────
# Loop principal
# ─────────────────────────────────────────────
main() {
  check_prerequisites

  while true; do
    header
    menu
    read -r opt

    case "$opt" in
      1)  action_provision ;;
      2)  action_apply ;;
      3)  action_remove ;;
      4)  action_status ;;
      5)  action_logs ;;
      6)  action_describe ;;
      7)  port_forward "grafana"      3000 "Grafana" ;;
      8)  port_forward "prometheus"   9090 "Prometheus" ;;
      9)  port_forward "alertmanager" 9093 "Alertmanager" ;;
      10) action_restart ;;
      11) action_edit_secret ;;
      12) action_netpol ;;
      0)  echo -e "\n  ${DIM}Até logo.${NC}\n"; exit 0 ;;
      *)  warn "Opção inválida. Tente novamente."; sleep 1 ;;
    esac
  done
}

main "$@"
