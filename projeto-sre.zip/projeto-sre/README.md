# Plataforma de Observabilidade Kubernetes

Stack de observabilidade corporativa alinhada aos princípios Cloud Native, CNCF, DevOps e SRE.

## Arquitetura

```
┌─────────────────────────────────────────────────────────────────┐
│                     Namespace: observability                     │
│                                                                  │
│  ┌─────────────┐    ┌──────────────────┐    ┌────────────────┐  │
│  │Node Exporter│    │  kube-state-     │    │   Promtail     │  │
│  │ (DaemonSet) │    │  metrics         │    │  (DaemonSet)   │  │
│  └──────┬──────┘    └────────┬─────────┘    └───────┬────────┘  │
│         │  métricas node     │  métricas K8s         │  logs     │
│         └──────────┬─────────┘                       │           │
│                    ▼                                  ▼           │
│            ┌──────────────┐                  ┌──────────────┐   │
│            │  Prometheus  │                  │     Loki     │   │
│            │  (30d ret.)  │                  │  (30d ret.)  │   │
│            └──────┬───────┘                  └──────┬───────┘   │
│                   │                                  │           │
│                   │  alertas                         │           │
│                   ▼                                  │           │
│           ┌───────────────┐                          │           │
│           │ Alertmanager  │                          │           │
│           │Teams/Slack/   │                          │           │
│           │Email/Webhook  │                          │           │
│           └───────────────┘                          │           │
│                   │              métricas + logs      │           │
│                   └──────────────────┬───────────────┘           │
│                                      ▼                           │
│                              ┌──────────────┐                   │
│                              │    Grafana   │                   │
│                              │  (PVC perm.) │                   │
│                              └──────────────┘                   │
└─────────────────────────────────────────────────────────────────┘
```

## Componentes

| Componente | Imagem | Função |
|---|---|---|
| Prometheus | `prom/prometheus:v2.51.0` | Coleta e armazena métricas (retenção 30d) |
| Node Exporter | `prom/node-exporter:v1.7.0` | Métricas de CPU, memória, disco, rede por node |
| kube-state-metrics | `registry.k8s.io/kube-state-metrics/kube-state-metrics:v2.12.0` | Métricas de workloads K8s (Deployments, Pods, Jobs) |
| Loki | `grafana/loki:3.0.0` | Armazenamento de logs (retenção 30d) |
| Promtail | `grafana/promtail:3.0.0` | Coleta de logs de todos os pods |
| Alertmanager | `prom/alertmanager:v0.27.0` | Roteamento de alertas (Teams, Slack, email, webhooks) |
| Grafana | `grafana/grafana:10.4.2` | Visualização com datasources pré-configurados (Prometheus, Loki, Alertmanager) |

## Estrutura do Repositório

```
projeto-sre/
├── namespace.yaml
├── kustomization.yaml
├── Makefile                      # make provision / apply / remove / grafana / logs ...
├── deploy.sh                     # menu interativo de deploy (wizard com preflight, rollback, saúde)
├── manage.sh                     # painel interativo de operações (logs, port-forward, restart)
├── Projeto de Implantação da Plataforma de Observabilidade Kubernetes.pdf
├── Projeto de Implantação da Plataforma de Observabilidade Kubernetes.docx
├── prometheus/
│   ├── serviceaccount.yaml
│   ├── clusterrole.yaml
│   ├── clusterrolebinding.yaml
│   ├── configmap.yaml            # scrape configs: apiservers, nodes, cadvisor, node-exporter, ksm, pods
│   ├── pvc.yaml                  # 50Gi, retenção 30 dias
│   ├── deployment.yaml           # strategy: Recreate (volume único)
│   └── service.yaml
├── node-exporter/
│   ├── serviceaccount.yaml
│   ├── clusterrole.yaml
│   ├── clusterrolebinding.yaml
│   ├── daemonset.yaml            # hostNetwork + hostPID, tolera control-plane
│   └── service.yaml              # headless (ClusterIP: None)
├── kube-state-metrics/
│   ├── serviceaccount.yaml
│   ├── clusterrole.yaml          # list/watch de todos os workloads K8s
│   ├── clusterrolebinding.yaml
│   ├── deployment.yaml           # porta 8080 (métricas) + 8081 (telemetria)
│   └── service.yaml
├── loki/
│   ├── configmap.yaml            # schema v13, retenção 30 dias (720h), compactor
│   ├── statefulset.yaml          # PVC 10Gi
│   └── service.yaml              # ClusterIP + Headless
├── promtail/
│   ├── serviceaccount.yaml
│   ├── clusterrole.yaml
│   ├── clusterrolebinding.yaml
│   ├── configmap.yaml            # pipeline CRI, labels: namespace/pod/container/node
│   └── daemonset.yaml            # tolera control-plane, monta /var/log e /var/lib/docker
├── alertmanager/
│   ├── configmap.yaml            # rotas: critical → Teams + Slack + email / warning → Slack
│   ├── deployment.yaml
│   └── service.yaml
├── alerts/
│   └── cluster-alerts.yaml       # ConfigMap prometheus-rules: cluster + kubernetes + application
├── grafana/
│   ├── secret.yaml               # credenciais via Secret (não hardcoded)
│   ├── pvc.yaml                  # 5Gi, retenção permanente
│   ├── configmap-datasources.yaml # Prometheus + Loki + Alertmanager pré-configurados
│   ├── configmap-dashboards.yaml
│   ├── deployment.yaml           # anti-affinity, RollingUpdate (maxUnavailable: 0)
│   ├── service.yaml
│   └── poddisruptionbudget.yaml  # minAvailable: 1
└── network-policies/
    ├── default-deny.yaml         # deny all; libera DNS (53) e API K8s (443/6443) globalmente
    ├── prometheus.yaml           # ingress: grafana; egress: nodes:9100, ksm:8080, alertmanager:9093
    ├── grafana.yaml              # ingress: *:3000; egress: prometheus:9090, loki:3100, alertmanager:9093
    ├── loki.yaml                 # ingress: promtail + grafana:3100
    ├── promtail-netpol.yaml      # egress: loki:3100, API K8s (service discovery)
    └── alertmanager-netpol.yaml  # ingress: prometheus + grafana:9093; egress: HTTPS/SMTP
```

## Pré-requisitos

| Ferramenta | Versão mínima | Verificar |
|---|---|---|
| kubectl | 1.27+ | `kubectl version --client` |
| Kubernetes cluster | 1.27+ | `kubectl cluster-info` |
| kustomize | embutido no kubectl 1.14+ | `kubectl kustomize --help` |

> **Antes do primeiro deploy:** edite [grafana/secret.yaml](grafana/secret.yaml) e troque o valor de `admin-password`. O valor padrão é apenas para desenvolvimento local.

## Deploy

### Usando Make (recomendado)

```bash
# Ver todos os comandos disponíveis
make help

# Abrir o menu interativo de deploy (recomendado para primeiro deploy)
make deploy

# Provisionar sem interação (CI/CD)
make provision

# Abrir o painel de operações (logs, restart, port-forward)
make panel
```

### Menu de deploy (`deploy.sh`)

| Opção | Ação |
|---|---|
| 1 | Novo deploy completo — preflight + dry-run + apply + aguarda rollout |
| 2 | Atualizar stack — exibe diff e aplica |
| 3 | Rollback de componente — lista revisões e faz undo |
| 4 | Pré-flight check — valida kubectl, cluster, manifests e senha |
| 5 | Diff — estado atual vs manifests |
| 6 | Verificar saúde — pods, deployments, PVCs |
| 7 | Configurar senha do Grafana — atualiza `grafana/secret.yaml` |
| 8 | Configurar Alertmanager — Teams, Slack, e-mail via wizard |
| 9 | Remover stack (preserva PVCs) |
| 10 | Remover stack + PVCs (destrutivo) |

### Usando kubectl diretamente

```bash
# Altere a senha do Grafana antes de aplicar em produção
# Edite grafana/secret.yaml e troque o valor de admin-password

# Aplicar toda a stack
kubectl apply -k .

# Acompanhar os pods subindo
kubectl get pods -n observability -w

# Verificar o status dos componentes
kubectl get all -n observability
```

## Acesso

```bash
# Grafana  (usuário: admin — senha definida em grafana/secret.yaml)
make grafana
# ou: kubectl port-forward svc/grafana 3000:3000 -n observability
# Acesse: http://localhost:3000

# Prometheus
make prometheus
# ou: kubectl port-forward svc/prometheus 9090:9090 -n observability
# Acesse: http://localhost:9090

# Alertmanager
make alertmanager
# ou: kubectl port-forward svc/alertmanager 9093:9093 -n observability
# Acesse: http://localhost:9093
```

### Datasources pré-configurados no Grafana

| Datasource | Endpoint | Padrão |
|---|---|---|
| Prometheus | `http://prometheus:9090` | Sim |
| Loki | `http://loki:3100` | Não |
| Alertmanager | `http://alertmanager:9093` | Não |

## Alertas Implementados

### Cluster
- `NodeDown` — node indisponível por mais de 2 minutos
- `NodeDiskPressure` — disco com menos de 15% livre
- `NodeDiskFull` — disco com menos de 5% livre (crítico)
- `NodeMemoryPressure` — memória com menos de 10% disponível
- `NodeCPUSaturation` — CPU acima de 90% por 10 minutos

### Kubernetes
- `PodCrashLoopBackOff` — pod em loop de crash por mais de 5 minutos
- `PodOOMKilled` — pod finalizado por falta de memória
- `DeploymentReplicasMismatch` — réplicas disponíveis diferentes do esperado
- `JobFailed` — job falhou
- `PodHighRestartCount` — mais de 5 restarts por hora
- `ContainerCPUThrottling` — throttling de CPU acima de 80%

### Aplicações
- `HighErrorRate` — taxa de erros HTTP 5xx acima de 5%
- `HighLatency` — latência p99 acima de 1 segundo

## Segurança

- **RBAC**: ServiceAccounts dedicadas com mínimo de privilégio para cada componente
- **Secrets**: credenciais do Grafana gerenciadas via `Secret` Kubernetes (não hardcoded em manifests)
- **Network Policies**: isolamento de tráfego entre componentes (`default-deny` + regras explícitas por componente); DNS (53) e API K8s (443/6443) liberados globalmente
- **Security Context**: todos os containers executam como non-root com `readOnlyRootFilesystem: true`
- **PodDisruptionBudget**: Grafana com `minAvailable: 1` para garantir disponibilidade durante manutenções

## Persistência

| Componente | Tamanho | Retenção |
|---|---|---|
| Prometheus | 50Gi | 30 dias |
| Loki | 10Gi | 30 dias |
| Grafana | 5Gi | Permanente |

## Configuração das Integrações de Alerta

Edite `alertmanager/configmap.yaml` e substitua os valores `CHANGEME`:

```yaml
# Microsoft Teams
url: "https://your-org.webhook.office.com/webhookb2/SEU_WEBHOOK"

# Slack
api_url: "https://hooks.slack.com/services/SEU_TOKEN"

# E-mail
smtp_smarthost: "seu-smtp.example.com:587"
to: "ops-team@example.com"
```

## Evolução Futura (LGTM Stack)

A arquitetura está preparada para expansão:
- **Grafana Alloy** — substituição do Promtail para coleta unificada de telemetria
- **Tempo** — distributed tracing (correlação Logs + Métricas + Traces)
- **OpenTelemetry** — padronização de instrumentação das aplicações
- **Argo CD** — GitOps para gerenciamento automatizado da stack
